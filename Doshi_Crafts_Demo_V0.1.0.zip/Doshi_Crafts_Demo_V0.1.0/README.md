# Doshi Crafts Mobile Demo

Version 0.1.0 • versionCode 1 • package `com.doshicrafts.demo`

A standalone Android demo of the supplied Doshi Crafts V10 website. The website UI, product data, catalogue, local photography, search, wishlist, bag and demo checkout are bundled inside the APK and loaded locally by WebView, so the demo does not require the website to be online.

## Build

- AGP 8.7.3
- Kotlin 2.0.21
- Gradle 8.10.2
- JDK 17
- compile/target SDK 35
- min SDK 26

This is a demo only. It does not submit real orders or process real payments.
