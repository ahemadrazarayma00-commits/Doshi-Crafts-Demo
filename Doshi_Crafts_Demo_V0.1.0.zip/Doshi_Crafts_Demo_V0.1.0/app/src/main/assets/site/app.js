'use strict';

let PRODUCTS = [];
let CONFIG = {};

const state = {
  cart: safeParse(localStorage.getItem('dc_v10_cart'), []),
  wishlist: safeParse(localStorage.getItem('dc_v10_wishlist'), []),
  collectionSort: 'featured'
};

const COLOR_HEX = {
  'Grey': '#858b8d',
  'Black': '#1c1b1b',
  'Rani Pink': '#c12a78',
  'Red': '#a9272c',
  'Royal Blue': '#1d2e55',
  'Royal Blue': '#1d2e55',
  'Green': '#1f5b49'
};

const app = document.querySelector('#app');
const overlay = document.querySelector('#overlay');
const focusableSelector = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

function safeParse(value, fallback) {
  try { return value ? JSON.parse(value) : fallback; } catch { return fallback; }
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}

function money(value) {
  if (value === null || value === undefined || value === '') return '';
  return `₹${Number(value).toLocaleString('en-IN')}`;
}

function priceMarkup(p, compact = false) {
  if (p.sellingPrice == null) return `<div class="price unavailable" aria-label="Price unavailable">Price unavailable</div>`;
  const hasMrp = p.mrp != null && Number(p.mrp) > Number(p.sellingPrice);
  const discount = p.discount != null ? p.discount : (hasMrp ? Math.round((1 - p.sellingPrice / p.mrp) * 100) : null);
  return `<div class="price ${compact ? 'compact-price' : ''}"><strong>${money(p.sellingPrice)}</strong>${hasMrp ? `<span class="mrp">${money(p.mrp)}</span>` : ''}${discount ? `<span class="off">${discount}% OFF</span>` : ''}</div>`;
}

function imageRole(src) {
  if (src.includes('01-flatlay')) return 'flatlay';
  if (src.includes('02-folded')) return 'folded';
  if (src.includes('03-lifestyle') || src.includes('04-model')) return 'lifestyle';
  return 'gallery';
}

function optimizedImage(src) {
  const m = src.match(/^images\/products\/(.+)\.(jpe?g|png)$/i);
  if (!m) return src;
  return `images/optimized/${m[1]}.webp`;
}

function productById(id) { return PRODUCTS.find(p => p.id === Number(id)); }
function productBySlug(slug) { return PRODUCTS.find(p => p.slug === slug); }

function saveState() {
  localStorage.setItem('dc_v10_cart', JSON.stringify(state.cart));
  localStorage.setItem('dc_v10_wishlist', JSON.stringify(state.wishlist));
  updateCounts();
}

function updateCounts() {
  const cartCount = document.querySelector('#cartCount');
  const wishlistCount = document.querySelector('#wishlistCount');
  if (cartCount) cartCount.textContent = state.cart.reduce((sum, line) => sum + line.qty, 0);
  if (wishlistCount) wishlistCount.textContent = state.wishlist.length;
}

function toast(message) {
  const node = document.querySelector('#toast');
  if (!node) return;
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove('show'), 1900);
}

function openDrawer(node, focusTarget) {
  closeDrawers(false);
  node.classList.add('open');
  node.setAttribute('aria-hidden', 'false');
  overlay.classList.add('show');
  document.body.classList.add('no-scroll');
  if (focusTarget) setTimeout(() => focusTarget.focus(), 100);
}

function closeDrawers(returnFocus = true) {
  document.querySelectorAll('.drawer,.mobile-menu').forEach(node => {
    node.classList.remove('open');
    node.setAttribute('aria-hidden', 'true');
  });
  overlay.classList.remove('show');
  if (!document.querySelector('#lightbox')?.classList.contains('open')) document.body.classList.remove('no-scroll');
  if (returnFocus && drawerReturnFocus) drawerReturnFocus.focus?.();
  drawerReturnFocus = null;
}

let drawerReturnFocus = null;

function routeFor(type, value = '') {
  if (type === 'home') return '#/';
  if (type === 'collection') {
    const map = {
      'All': 'all-shawls', 'Jaripatta': 'jaripatta', 'Kutchi': 'kutchi-shawls',
      'Woollen': 'woollen-shawls', 'New': 'new-arrivals'
    };
    if (String(value).startsWith('Color:')) return `#/collections/all-shawls?colour=${encodeURIComponent(String(value).slice(6))}`;
    return `#/collections/${map[value] || 'all-shawls'}`;
  }
  if (type === 'product') return `#/products/${encodeURIComponent(value)}`;
  if (type === 'wishlist') return '#/wishlist';
  if (type === 'about') return '#/about';
  if (type === 'checkout') return '#/checkout';
  if (type === 'confirmation') return '#/order-confirmation';
  return '#/';
}

function go(type, value = '') {
  const target = routeFor(type, value);
  closeDrawers(false);
  if (location.hash === target) renderRoute();
  else location.hash = target;
}

function routeState() {
  const raw = (location.hash || '#/').replace(/^#/, '');
  const qIndex = raw.indexOf('?');
  const path = (qIndex >= 0 ? raw.slice(0, qIndex) : raw).replace(/\/+$/, '') || '/';
  const params = new URLSearchParams(qIndex >= 0 ? raw.slice(qIndex + 1) : '');
  if (path === '/') return { page: 'home' };
  if (path === '/wishlist') return { page: 'wishlist' };
  if (path === '/about') return { page: 'about' };
  if (path === '/checkout') return { page: 'checkout' };
  if (path === '/order-confirmation') return { page: 'confirmation' };
  if (path.startsWith('/products/')) return { page: 'product', slug: decodeURIComponent(path.slice('/products/'.length)) };
  if (path.startsWith('/collections/')) {
    const slug = path.slice('/collections/'.length);
    const map = { 'all-shawls': 'All', 'jaripatta': 'Jaripatta', 'kutchi-shawls': 'Kutchi', 'woollen-shawls': 'Woollen', 'new-arrivals': 'New' };
    const colour = params.get('colour');
    return { page: 'collection', category: colour ? `Color:${colour}` : (map[slug] || 'All') };
  }
  return { page: 'notfound' };
}

function setMeta(title, description) {
  document.title = `${title} — Doshi Crafts`;
  document.querySelector('meta[name="description"]')?.setAttribute('content', description);
  document.querySelector('meta[property="og:title"]')?.setAttribute('content', `${title} — Doshi Crafts`);
  document.querySelector('meta[property="og:description"]')?.setAttribute('content', description);
}

function setNavCurrent() {
  const current = routeState();
  document.querySelectorAll('[data-nav]').forEach(link => {
    const key = link.dataset.nav;
    const active = (current.page === 'home' && key === 'home') || (current.page === 'collection' && key === 'shop');
    if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
  });
}

function renderRoute() {
  closeDrawers(false);
  const r = routeState();
  document.body.classList.toggle('checkout-mode', r.page === 'checkout' || r.page === 'confirmation');
  if (r.page === 'home') renderHome();
  else if (r.page === 'collection') renderCollection(r.category);
  else if (r.page === 'product') renderProduct(r.slug);
  else if (r.page === 'wishlist') renderWishlist();
  else if (r.page === 'about') renderAbout();
  else if (r.page === 'checkout') renderCheckout();
  else if (r.page === 'confirmation') renderConfirmation();
  else renderNotFound();
  setNavCurrent();
  bindDynamic();
  updateCounts();
  window.scrollTo({ top: 0, behavior: 'auto' });
}

function productCard(p) {
  const wished = state.wishlist.includes(p.id);
  const secondary = p.images.find(src => imageRole(src) === 'lifestyle') || p.images[1] || p.images[0];
  return `<article class="product-card">
    <div class="product-image-wrap">
      <a class="product-image" href="${routeFor('product', p.slug)}" data-product="${escapeHtml(p.slug)}" aria-label="View ${escapeHtml(p.name)}">
        <img class="card-primary" src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt="${escapeHtml(p.name)} shown flat to display the full design" loading="lazy" decoding="async">
        <img class="card-secondary" src="${optimizedImage(secondary)}" data-fallback-src="${secondary}" alt="" aria-hidden="true" loading="lazy" decoding="async">
      </a>
      ${p.isBestSeller ? '<span class="badge">BESTSELLER</span>' : p.isNew ? '<span class="badge">NEW</span>' : ''}
      <button class="heart ${wished ? 'active' : ''}" data-wish="${p.id}" aria-label="${wished ? 'Remove from' : 'Add to'} wishlist">${wished ? '♥' : '♡'}</button>
      <span class="card-view">VIEW SHAWL</span>
    </div>
    <div class="product-meta">
      <div class="product-kicker"><i class="mini-shade" style="--shade:${COLOR_HEX[p.colour] || '#999'}"></i> JARIPATTA · ${escapeHtml(p.colour.toUpperCase())}</div>
      <h3><a href="${routeFor('product', p.slug)}" data-product="${escapeHtml(p.slug)}">${escapeHtml(p.name)}</a></h3>
      <div class="card-price-row">${priceMarkup(p, true)}<button class="card-add" data-add="${p.id}" aria-label="Add ${escapeHtml(p.name)} to bag">＋</button></div>
      <button class="btn quick mobile-card-add" data-add="${p.id}">ADD TO BAG</button>
    </div>
  </article>`;
}

function productGrid(items) {
  return `<div class="product-grid">${items.map(productCard).join('')}</div>`;
}

function collectionCard(category, title, subtitle, productId) {
  const p = productById(productId);
  const image = p ? optimizedImage(p.images.find(src => imageRole(src) === 'lifestyle') || p.images[0]) : '';
  return `<a class="collection-card" href="${routeFor('collection', category)}" data-route="collection" data-category="${category}">
    <img src="${image}" data-fallback-src="${p?.images.find(src => imageRole(src) === 'lifestyle') || p?.images[0] || ''}" alt="${escapeHtml(title)} collection" loading="lazy" decoding="async">
    <span class="collection-shade"></span>
    <span class="collection-copy"><small>${escapeHtml(subtitle)}</small><strong>${escapeHtml(title)}</strong><span>SHOP COLLECTION →</span></span>
  </a>`;
}

function colorItem(colour) {
  const p = PRODUCTS.find(x => x.colour === colour);
  return `<a class="shade-card" href="${p ? routeFor('product', p.slug) : routeFor('collection', `Color:${colour}`)}" ${p ? `data-product="${p.slug}"` : `data-route="collection" data-category="Color:${colour}"`}>
    <span class="shade-dot" style="--shade:${COLOR_HEX[colour] || '#999'}"></span>
    <span>${escapeHtml(colour)}</span>
  </a>`;
}

function safeAnnouncement() {
  const claims = [];
  if (CONFIG.freeShipping === true) claims.push('FREE SHIPPING ACROSS INDIA');
  if (CONFIG.codAvailable === true) claims.push('COD AVAILABLE');
  if (Number(CONFIG.returnDays) > 0) claims.push(`${CONFIG.returnDays}-DAY RETURNS`);
  const bar = document.querySelector('#announcementText');
  const wrap = document.querySelector('#announcement');
  if (claims.length) {
    bar.textContent = claims.join('  •  ');
    wrap.hidden = false;
  } else {
    wrap.hidden = true;
  }
}

function footer() {
  const instagram = CONFIG.instagramUrl
    ? `<a href="${escapeHtml(CONFIG.instagramUrl)}" target="_blank" rel="noopener">${escapeHtml(CONFIG.instagramHandle || '@DOSHICRAFTS')}</a>`
    : `<span>${escapeHtml(CONFIG.instagramHandle || '@DOSHICRAFTS')}</span>`;
  return `<footer class="footer">
    <div class="footer-pattern" aria-hidden="true"></div>
    <div class="footer-grid">
      <div class="footer-brand"><img src="assets/doshi-logo.svg" alt="Doshi Crafts"><p>${escapeHtml(CONFIG.tagline || '')}</p><p>Traditional Kutchi Jaripatta shawls in rich woollen colourways.</p></div>
      <div><h4>SHOP</h4><a href="#/collections/all-shawls" data-route="collection" data-category="All">All Shawls</a><a href="#/collections/jaripatta" data-route="collection" data-category="Jaripatta">Jaripatta</a><a href="#/collections/new-arrivals" data-route="collection" data-category="New">New Arrivals</a></div>
      <div><h4>DISCOVER</h4><a href="#/about" data-route="about">Our Story</a><a href="#/wishlist" data-route="wishlist">Wishlist</a><a href="#/collections/jaripatta" data-route="collection" data-category="Jaripatta">The Jaripatta Edit</a></div>
      <div><h4>FOLLOW</h4>${instagram}<p>Traditional warmth, colour and Jaripatta details from Doshi Crafts.</p></div>
    </div>
    <div class="footer-bottom"><span>© 2026 Doshi Crafts</span><span>FROM KUTCH, WITH WARMTH.</span></div>
  </footer>`;
}

function heroLetter(letter, productId, index) {
  const p = productById(productId);
  const lifestyle = p?.images.find(src => imageRole(src) === 'lifestyle') || p?.images[0];
  const positions = ['42% center', '52% center', '55% center', '48% center', '50% center'];
  return `<span class="hero-letter" style="--letter-img:url('${optimizedImage(lifestyle || '')}');--letter-pos:${positions[index] || 'center'}" aria-hidden="true">${escapeHtml(letter)}</span>`;
}

function detailTile(label, note, productId, imageIndex, position = 'center') {
  const p = productById(productId);
  const src = p?.images[imageIndex] || p?.images[0] || '';
  return `<article class="detail-tile"><div class="detail-photo"><img src="${optimizedImage(src)}" data-fallback-src="${src}" alt="${escapeHtml(p?.name || 'Jaripatta shawl')} detail" loading="lazy" style="object-position:${position}"></div><div class="detail-copy"><span>${escapeHtml(label)}</span><p>${escapeHtml(note)}</p></div></article>`;
}

function moodCard(title, subtitle, ids) {
  const ps = ids.map(productById).filter(Boolean);
  return `<a class="mood-card" href="${routeFor('product', ps[0]?.slug || '')}" data-product="${ps[0]?.slug || ''}"><div class="mood-images">${ps.slice(0,2).map(p => `<img src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt="${escapeHtml(p.colour)} Jaripatta shawl" loading="lazy">`).join('')}</div><div class="mood-copy"><small>${escapeHtml(subtitle)}</small><strong>${escapeHtml(title)}</strong><span>EXPLORE →</span></div></a>`;
}

function renderHome() {
  setMeta('Traditional Woollen Shawls from Kutch', 'Discover Doshi Crafts Kutchi Jaripatta and 100% woollen shawls in rich traditional colourways.');
  const hero = CONFIG.hero || {};
  const word = hero.word || 'SHAWL';
  const letterProducts = hero.letterProducts || [3,2,6,1,5];
  const best = PRODUCTS.filter(p => p.isBestSeller).slice(0, 4);
  const newArrivals = PRODUCTS.filter(p => p.isNew).slice(0, 3);
  app.innerHTML = `
    <section class="type-hero">
      <div class="hero-paper hero-paper-a"></div><div class="hero-paper hero-paper-b"></div>
      <div class="hero-motif" aria-hidden="true"></div>
      <div class="type-hero-inner">
        <div class="hero-topline"><div class="type-hero-kicker">${escapeHtml(hero.kicker || 'DOSHI CRAFTS • KUTCH')}</div><img class="hero-seal" src="assets/doshi-seal.svg" alt=""></div>
        <div class="shawl-word" role="img" aria-label="${escapeHtml(word)}">${[...word].map((letter, i) => heroLetter(letter, letterProducts[i % letterProducts.length], i)).join('')}</div>
        <div class="hero-copy-row">
          <div><div class="hero-display-line">${escapeHtml(hero.headline || 'Tradition, Wrapped in Warmth.')}</div><p>${escapeHtml(hero.support || '')}</p></div>
          <div class="hero-actions"><a class="btn" href="#/collections/all-shawls" data-route="collection" data-category="All">SHOP THE COLLECTION</a><a class="text-link hero-text-link" href="#/about" data-route="about">OUR STORY →</a></div>
        </div>
        <div class="hero-shades"><span>6 JARIPATTA SHADES</span><span>100% WOOLLEN</span><span>TWO-SHORT-END BORDER & TASSELS</span></div>
      </div>
    </section>

    <section class="brand-proof" aria-label="Collection highlights"><div><strong>01</strong><span>100% Woollen</span></div><div><strong>02</strong><span>Kutchi Jaripatta</span></div><div><strong>03</strong><span>Six Rich Shades</span></div><div><strong>04</strong><span>Full-Screen Product View</span></div></section>

    <section class="section section-soft featured-section"><div class="section-head split-head"><div><div class="eyebrow">THE CURRENT EDIT</div><h2>Signature Jaripatta</h2></div><div><p>Six colours. One distinctive traditional detail. Built around warmth, drape and the character of Kutch.</p><a class="text-link" href="#/collections/all-shawls" data-route="collection" data-category="All">VIEW ALL SHAWLS →</a></div></div>${productGrid(best)}</section>

    <section class="editorial edit-section editorial-upgrade"><div class="editorial-media"><img src="${optimizedImage(productById(4).images[2])}" data-fallback-src="${productById(4).images[2]}" alt="Red Kutchi Jaripatta shawl styled in a warm interior" loading="lazy"><span class="editorial-number">01 / SIGNATURE</span></div><div class="editorial-copy"><div class="eyebrow">THE JARIPATTA EDIT</div><h2>A Border That<br>Defines The Shawl.</h2><p>Signature Jaripatta detailing and tassels finish the two short ends, giving every colourway its recognisable character.</p><div class="editorial-stat"><span>06</span><p>current colourways to choose from</p></div><a class="btn" href="#/collections/jaripatta" data-route="collection" data-category="Jaripatta">DISCOVER JARIPATTA</a></div></section>

    <section class="section detail-section"><div class="section-head split-head"><div><div class="eyebrow">LOOK CLOSER</div><h2>The Doshi Detail</h2></div><p>Use the product gallery to inspect the full shawl. These crops highlight the details that give Jaripatta its identity.</p></div><div class="detail-grid">
      ${detailTile('THE DRAPE', 'A full-width view keeps the colour, motifs and proportion easy to understand.', 3, 0, 'center')}
      ${detailTile('THE JARIPATTA END', 'Decorative Jaripatta detailing sits on the two short ends.', 1, 0, '18% center')}
      ${detailTile('THE FINISH', 'Tassels remain on the two short ends, matching the original shawl construction.', 5, 0, '88% center')}
    </div></section>

    <section class="section mood-section"><div class="section-head"><div class="eyebrow">FIND YOUR COLOUR STORY</div><h2>Choose The Mood.</h2><p>A simpler way to discover the shade that fits your wardrobe.</p></div><div class="mood-grid">
      ${moodCard('Quiet Neutrals', 'GREY + BLACK', [1,2])}
      ${moodCard('Festive Brights', 'RANI PINK + RED', [3,4])}
      ${moodCard('Deep Jewel Tones', 'NAVY + GREEN', [5,6])}
    </div></section>

    <div class="marquee brand-strip" aria-label="Doshi Crafts brand values"><div>FROM KUTCH WITH WARMTH ✦ 100% WOOLLEN ✦ JARIPATTA DETAIL ✦ SIX SIGNATURE SHADES ✦ FROM KUTCH WITH WARMTH ✦ 100% WOOLLEN ✦ JARIPATTA DETAIL ✦ SIX SIGNATURE SHADES ✦</div></div>

    <section class="editorial rooted rooted-upgrade"><div class="editorial-copy"><div class="eyebrow">FROM KUTCH, WITH WARMTH</div><h2>Rooted in Kutch.<br>Styled for Today.</h2><p>Doshi Crafts celebrates the timeless textile heritage of Kutch through shawls designed for comfort, warmth and everyday elegance.</p><p>The current collection brings together traditional motifs, rich colour and 100% woollen fabric with signature Jaripatta detailing.</p><a class="text-link" href="#/about" data-route="about">READ THE DOSHI CRAFTS STORY →</a></div><div class="editorial-media"><img src="${optimizedImage(productById(1).images[2])}" data-fallback-src="${productById(1).images[2]}" alt="Grey Jaripatta shawl styled in a calm interior" loading="lazy"><div class="image-caption">GREY JARIPATTA · DOSHI CRAFTS</div></div></section>

    ${newArrivals.length ? `<section class="section new-arrival-section"><div class="section-head split-head"><div><div class="eyebrow">FRESH COLOUR</div><h2>New Arrivals</h2></div><div><p>Recently added shades from the current Jaripatta edit.</p><a class="text-link" href="#/collections/new-arrivals" data-route="collection" data-category="New">SHOP NEW ARRIVALS →</a></div></div>${productGrid(newArrivals)}</section>` : ''}

    <section class="wear-editorial"><div class="wear-copy"><div class="eyebrow light-eyebrow">WEAR YOUR HERITAGE</div><h2>One Shawl.<br>Many Moments.</h2><p>From a quiet winter layer to festive styling, let colour and Jaripatta detailing do the talking.</p><a class="btn light" href="#/collections/all-shawls" data-route="collection" data-category="All">FIND YOUR SHADE</a></div><div class="wear-collage"><img src="${optimizedImage(productById(6).images[3] || productById(6).images[2])}" data-fallback-src="${productById(6).images[3] || productById(6).images[2]}" alt="Green Jaripatta shawl styled on a model" loading="lazy"><img src="${optimizedImage(productById(3).images[2])}" data-fallback-src="${productById(3).images[2]}" alt="Rani Pink Jaripatta shawl styled in an interior" loading="lazy"><img src="${optimizedImage(productById(2).images[2])}" data-fallback-src="${productById(2).images[2]}" alt="Black Jaripatta shawl styled in an interior" loading="lazy"></div></section>

    <section class="section archive-section"><div class="section-head split-head"><div><div class="eyebrow">THE COLOUR ARCHIVE</div><h2>${escapeHtml(CONFIG.instagramHandle || '@DOSHICRAFTS')}</h2></div><p>Six current Jaripatta colours, collected in one visual row.</p></div><div class="instagram-grid archive-grid">${PRODUCTS.map(p => `<a href="${routeFor('product', p.slug)}" data-product="${p.slug}" aria-label="View ${escapeHtml(p.name)}"><img src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt="${escapeHtml(p.colour)} Jaripatta shawl" loading="lazy"><span>${escapeHtml(p.colour)}</span></a>`).join('')}</div></section>

    <section class="closing-cta closing-brand"><div><div class="eyebrow">TRADITION, WRAPPED IN WARMTH</div><h2>Find the shade that feels like yours.</h2><p>Explore the complete Doshi Crafts Jaripatta collection.</p></div><a class="btn light" href="#/collections/all-shawls" data-route="collection" data-category="All">SHOP ALL SHAWLS</a></section>
    ${footer()}`;
}

function filterCollection(category) {
  if (category === 'New') return PRODUCTS.filter(p => p.isNew);
  if (String(category).startsWith('Color:')) return PRODUCTS.filter(p => p.colour === String(category).slice(6));
  if (category === 'Jaripatta') return PRODUCTS.filter(p => p.category === 'Jaripatta');
  if (category === 'Kutchi') return PRODUCTS.filter(p => p.collection.includes('Kutchi Shawls'));
  if (category === 'Woollen') return PRODUCTS.filter(p => p.collection.includes('100% Woollen'));
  return [...PRODUCTS];
}

function collectionCopy(category) {
  if (category === 'New') return ['New Arrivals', 'Fresh shades recently added to the Doshi Crafts Jaripatta edit.'];
  if (String(category).startsWith('Color:')) {
    const c = String(category).slice(6); return [`${c} Shawls`, `Explore the ${c} Jaripatta colourway.`];
  }
  if (category === 'Jaripatta') return ['Jaripatta Shawls', 'Traditional Kutchi Jaripatta shawls in six rich colourways.'];
  if (category === 'Kutchi') return ['Kutchi Shawls', 'Explore the current Doshi Crafts Jaripatta collection rooted in Kutchi styling.'];
  if (category === 'Woollen') return ['100% Woollen Shawls', 'Warm woollen Jaripatta shawls for winter styling and everyday elegance.'];
  return ['All Shawls', 'Explore the complete Doshi Crafts Jaripatta shawl collection.'];
}

function sortProducts(items, sort) {
  const arr = [...items];
  if (sort === 'low') arr.sort((a,b) => (a.sellingPrice ?? Infinity) - (b.sellingPrice ?? Infinity));
  if (sort === 'high') arr.sort((a,b) => (b.sellingPrice ?? -Infinity) - (a.sellingPrice ?? -Infinity));
  if (sort === 'new') arr.sort((a,b) => Number(b.isNew) - Number(a.isNew));
  return arr;
}

function collectionHeroProduct(category) {
  if (category === 'New') return productById(6) || productById(3);
  if (String(category).startsWith('Color:')) return PRODUCTS.find(p => p.colour === String(category).slice(6)) || PRODUCTS[0];
  if (category === 'Jaripatta') return productById(4) || PRODUCTS[0];
  if (category === 'Kutchi') return productById(1) || PRODUCTS[0];
  if (category === 'Woollen') return productById(6) || PRODUCTS[0];
  return productById(3) || PRODUCTS[0];
}

function renderCollection(category = 'All') {
  const [title, intro] = collectionCopy(category);
  setMeta(title, intro);
  const items = filterCollection(category);
  const heroP = collectionHeroProduct(category);
  const heroImg = heroP?.images.find(src => imageRole(src) === 'lifestyle') || heroP?.images[0] || '';
  app.innerHTML = `<section class="collection-hero-v6"><div class="collection-hero-copy"><div class="eyebrow">DOSHI CRAFTS COLLECTION</div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(intro)}</p><div class="collection-count">${items.length} SHAWL${items.length === 1 ? '' : 'S'} · 100% WOOLLEN</div></div><div class="collection-hero-media"><img src="${optimizedImage(heroImg)}" data-fallback-src="${heroImg}" alt="${escapeHtml(heroP?.name || title)}" loading="eager"><div class="collection-hero-stamp">FROM KUTCH<br>WITH WARMTH</div></div></section>
    <section class="collection-shell collection-shell-v6">
      <div class="collection-shade-nav"><span>SHOP BY SHADE</span>${['Grey','Black','Rani Pink','Red','Royal Blue','Green'].map(c => {
        const p = PRODUCTS.find(x=>x.colour===c); return `<a href="${p ? routeFor('product',p.slug) : routeFor('collection',`Color:${c}`)}" ${p ? `data-product="${p.slug}"` : `data-route="collection" data-category="Color:${c}"`}><i style="--shade:${COLOR_HEX[c] || '#999'}"></i>${escapeHtml(c)}</a>`;
      }).join('')}</div>
      <div class="toolbar"><div class="filter-group">${[['All','ALL'],['Jaripatta','JARIPATTA'],['Kutchi','KUTCHI'],['Woollen','100% WOOLLEN'],['New','NEW']].map(([key,label]) => `<a class="chip ${category === key ? 'active' : ''}" href="${routeFor('collection', key)}" data-route="collection" data-category="${key}">${label}</a>`).join('')}</div>
      <label class="sort-label">SORT <select id="sortSelect" aria-label="Sort products"><option value="featured">Featured</option><option value="new">Newest</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option></select></label></div>
      <div id="collectionGrid">${items.length ? productGrid(items) : '<div class="empty"><h2>No shawls found.</h2><p>Try another collection or shade.</p></div>'}</div>
    </section><section class="collection-endnote"><div class="eyebrow">THE DOSHI CRAFTS POINT OF VIEW</div><h2>Clear product. Rich colour. Quiet confidence.</h2><p>Every current Jaripatta shawl is presented with the full textile visible first, so the border, tassels and overall colour can be understood before styling imagery takes over.</p><a class="text-link" href="#/about" data-route="about">DISCOVER OUR STORY →</a></section>${footer()}`;
  const select = document.querySelector('#sortSelect');
  if (select) {
    select.value = state.collectionSort;
    select.addEventListener('change', () => {
      state.collectionSort = select.value;
      document.querySelector('#collectionGrid').innerHTML = productGrid(sortProducts(items, state.collectionSort));
      bindDynamic();
    });
  }
}

function variantSwatches(current) {
  return PRODUCTS.map(p => `<a class="variant-swatch ${p.id === current.id ? 'active' : ''}" href="${routeFor('product', p.slug)}" data-product="${p.slug}" aria-label="View ${escapeHtml(p.colour)} shawl"><span class="variant-photo"><img src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt="" loading="lazy"></span><small>${escapeHtml(p.colour)}</small></a>`).join('');
}

function productFacts(p) {
  return `<div class="product-facts"><div><span>MATERIAL</span><strong>${escapeHtml(p.material)}</strong></div><div><span>STYLE</span><strong>Kutchi Jaripatta</strong></div><div><span>BORDER</span><strong>Two short ends</strong></div><div><span>TASSELS</span><strong>Two short ends</strong></div></div>`;
}

function businessAccordions(p) {
  const items = [
    ['PRODUCT DETAILS', `<p>${escapeHtml(p.description)}</p>`],
    ['PRODUCT HIGHLIGHTS', `<ul>${p.highlights.map(h => `<li>${escapeHtml(h)}</li>`).join('')}</ul>`],
    ['FABRIC & CARE', `<p>${escapeHtml(p.fabric)}. ${escapeHtml(p.care)}</p>`]
  ];
  if (p.dimensions) items.push(['DIMENSIONS', `<p>${escapeHtml(p.dimensions)}</p>`]);
  if (CONFIG.freeShipping !== null || CONFIG.shippingThreshold != null) {
    const text = CONFIG.freeShipping === true ? 'Free shipping is available.' : CONFIG.shippingThreshold != null ? `Shipping policy applies above ${money(CONFIG.shippingThreshold)}.` : 'Shipping charges apply according to the store policy.';
    items.push(['SHIPPING', `<p>${text}</p>`]);
  }
  if (Number(CONFIG.returnDays) > 0) items.push(['RETURNS & EXCHANGE', `<p>Returns or exchanges are available within ${Number(CONFIG.returnDays)} days, subject to the approved store policy.</p>`]);
  if (CONFIG.codAvailable !== null) items.push(['COD INFORMATION', `<p>${CONFIG.codAvailable ? 'Cash on delivery is available on eligible orders.' : 'Cash on delivery is not currently available.'}</p>`]);
  return `<div class="accordion">${items.map(([title, body], i) => `<details ${i === 0 ? 'open' : ''}><summary>${title}<span>+</span></summary>${body}</details>`).join('')}</div>`;
}

function renderProduct(slug) {
  const p = productBySlug(slug);
  if (!p) { renderNotFound(); return; }
  setMeta(p.name, p.description);
  const wished = state.wishlist.includes(p.id);
  const related = PRODUCTS.filter(x => x.id !== p.id).slice(0, 4);
  const whatsappButton = CONFIG.whatsappNumber ? `<button class="btn outline wide" id="whatsappBtn">ORDER ON WHATSAPP</button>` : '';
  app.innerHTML = `<nav class="breadcrumb" aria-label="Breadcrumb"><a href="#/" data-route="home">Home</a><span>/</span><a href="#/collections/jaripatta" data-route="collection" data-category="Jaripatta">Jaripatta</a><span>/</span><span>${escapeHtml(p.colour)}</span></nav>
    <section class="product-page product-page-v6">
      <div class="product-media">
        <div class="product-main-frame">
          <img id="productMainImage" src="${p.images[0]}" alt="${escapeHtml(p.name)} full product view" data-lightbox-main="0">
          <div class="product-image-ui"><span id="productImageCounter">1 / ${p.images.length}</span><button class="view-full" id="viewFullBtn">⛶ VIEW FULL SCREEN</button></div>
          <button class="gallery-nav gallery-prev" id="galleryPrev" aria-label="Previous product image">‹</button><button class="gallery-nav gallery-next" id="galleryNext" aria-label="Next product image">›</button>
        </div>
        <div class="product-thumbs" aria-label="Product image thumbnails">${p.images.map((img, i) => `<button class="product-thumb ${i === 0 ? 'active' : ''}" data-thumb-index="${i}" aria-label="Show image ${i + 1}"><img src="${optimizedImage(img)}" data-fallback-src="${img}" alt=""></button>`).join('')}</div>
        <p class="gallery-note">Open full screen to inspect the weave, border and tassel details.</p>
      </div>
      <div class="product-info">
        <div class="eyebrow">JARIPATTA · ${escapeHtml(p.colour.toUpperCase())}</div>
        <div class="product-title-row"><h1>${escapeHtml(p.name)}</h1><button class="product-wish ${wished ? 'active' : ''}" data-wish="${p.id}" aria-label="${wished ? 'Remove from' : 'Add to'} wishlist">${wished ? '♥' : '♡'}</button></div>
        ${priceMarkup(p)}
        <div class="variant-block"><div class="variant-label"><strong>Explore shades</strong><span>${escapeHtml(p.colour)}</span></div><div class="variant-row">${variantSwatches(p)}</div></div>
        ${productFacts(p)}
        <div class="product-confidence"><span>100% WOOLLEN</span><span>FULL-SCREEN ZOOM</span><span>DEMO COLLECTION</span></div>
        <div class="cta-stack"><button class="btn wide" data-add="${p.id}">ADD TO BAG</button><button class="btn outline wide" data-add="${p.id}" data-buy="1">BUY NOW</button>${whatsappButton}</div>
        ${businessAccordions(p)}
      </div>
    </section>
    <section class="product-detail-story"><div class="section-head"><div class="eyebrow">SEE THE SHAWL, NOT JUST THE SKU</div><h2>Full View. Fold. Styling.</h2><p>Three ways to understand the same product before you decide.</p></div><div class="product-story-grid">${p.images.slice(0,3).map((img,i)=>`<button data-story-image="${i}" class="product-story-card"><img src="${optimizedImage(img)}" data-fallback-src="${img}" alt="${escapeHtml(p.name)} ${['full view','folded view','styled view'][i] || 'detail'}" loading="lazy"><span>${['01 · FULL VIEW','02 · FOLD & BORDER','03 · STYLED VIEW'][i] || `0${i+1} · DETAIL`}</span></button>`).join('')}</div></section>
    <section class="section compact related"><div class="section-head"><div class="eyebrow">OTHER SHADES</div><h2>You May Also Like</h2></div>${productGrid(related)}</section>
    <div class="mobile-buy-bar"><div><small>${escapeHtml(p.shortName || p.name)}</small>${priceMarkup(p,true)}</div><button class="btn" data-add="${p.id}">ADD TO BAG</button></div>${footer()}`;
  initProductGallery(p);
  document.querySelectorAll('[data-story-image]').forEach(btn => btn.addEventListener('click', () => openLightbox(p.images, Number(btn.dataset.storyImage), p.name, btn)));
  if (CONFIG.whatsappNumber) {
    document.querySelector('#whatsappBtn')?.addEventListener('click', () => {
      const number = String(CONFIG.whatsappNumber).replace(/\D/g, '');
      const msg = encodeURIComponent(`Hi Doshi Crafts, I'm interested in the ${p.name}.`);
      window.open(`https://wa.me/${number}?text=${msg}`, '_blank', 'noopener');
    });
  }
}

function renderWishlist() {
  setMeta('Wishlist', 'Your saved Doshi Crafts shawls.');
  const items = PRODUCTS.filter(p => state.wishlist.includes(p.id));
  app.innerHTML = `<section class="page-hero"><div class="eyebrow">SAVED FOR LATER</div><h1>Your Wishlist</h1><p>Keep your favourite shades close while you compare.</p></section><section class="collection-shell">${items.length ? productGrid(items) : '<div class="empty"><h2>Your wishlist is empty.</h2><p>Use the heart on any shawl to save it here.</p><a class="btn" href="#/collections/all-shawls" data-route="collection" data-category="All">EXPLORE SHAWLS</a></div>'}</section>${footer()}`;
}

function renderAbout() {
  setMeta('About Doshi Crafts', 'Doshi Crafts celebrates the timeless textile heritage of Kutch through warm, elegant woollen shawls.');
  app.innerHTML = `<section class="about-hero about-hero-v6"><div class="about-copy"><div class="eyebrow">DOSHI CRAFTS • KUTCH</div><h1>Tradition,<br>Wrapped in Warmth.</h1><p>Doshi Crafts celebrates the timeless textile heritage of Kutch through shawls designed for comfort, warmth and everyday elegance.</p><p>Our current collection brings together traditional motifs, rich colour and 100% woollen fabric with signature Jaripatta detailing along the two short ends.</p><a class="btn" href="#/collections/all-shawls" data-route="collection" data-category="All">SHOP SHAWLS</a></div><div class="about-media"><img src="${optimizedImage(productById(3).images[2])}" data-fallback-src="${productById(3).images[2]}" alt="Rani Pink Jaripatta shawl styled in an interior"><img class="about-seal" src="assets/doshi-seal.svg" alt=""></div></section>
  <section class="brand-principles"><div><span>01</span><h2>Colour With Character</h2><p>Grey, Black, Rani Pink, Red, Royal Blue and Green make up the current Jaripatta colour story.</p></div><div><span>02</span><h2>Product Truth First</h2><p>The shawl is shown clearly, with its border and tassel placement kept true to the original product.</p></div><div><span>03</span><h2>Warmth Without Clutter</h2><p>A premium, restrained visual identity lets the textile remain the centre of attention.</p></div></section>
  <section class="editorial about-editorial"><div class="editorial-media"><img src="${optimizedImage(productById(6).images[3] || productById(6).images[2])}" data-fallback-src="${productById(6).images[3] || productById(6).images[2]}" alt="Green Jaripatta shawl styled on a model"></div><div class="editorial-copy"><div class="eyebrow">THE CURRENT COLLECTION</div><h2>Six Shades.<br>One Signature Detail.</h2><p>Every current colourway belongs to the same Jaripatta family: woollen fabric, traditional motifs, and decorative finishing on the two short ends.</p><a class="text-link" href="#/collections/jaripatta" data-route="collection" data-category="Jaripatta">EXPLORE JARIPATTA →</a></div></section>${footer()}`;
}

function renderNotFound() {
  setMeta('Page Not Found', 'The requested Doshi Crafts page could not be found.');
  app.innerHTML = `<section class="empty full-empty"><div class="eyebrow">DOSHI CRAFTS</div><h1>That page is not here.</h1><p>Return to the shawl collection.</p><a class="btn" href="#/" data-route="home">BACK HOME</a></section>${footer()}`;
}

function addCart(id) {
  const p = productById(id);
  if (!p) return;
  const line = state.cart.find(item => item.id === p.id);
  if (line) line.qty += 1; else state.cart.push({ id: p.id, qty: 1 });
  saveState();
  renderCart();
  toast(`${p.shortName || p.name} added to bag`);
}

function toggleWish(id) {
  const pos = state.wishlist.indexOf(id);
  if (pos >= 0) {
    state.wishlist.splice(pos, 1);
    toast('Removed from wishlist');
  } else {
    state.wishlist.push(id);
    toast('Saved to wishlist');
  }
  saveState();
  document.querySelectorAll(`[data-wish="${id}"]`).forEach(btn => {
    const wished = state.wishlist.includes(id);
    btn.textContent = wished ? '♥' : '♡';
    btn.classList.toggle('active', wished);
    btn.setAttribute('aria-label', `${wished ? 'Remove from' : 'Add to'} wishlist`);
  });
  if (routeState().page === 'wishlist') renderRoute();
}

function cartTotals() {
  const items = state.cart.map(line => ({ ...line, product: productById(line.id) })).filter(line => line.product);
  const subtotal = items.reduce((sumValue, line) => sumValue + Number(line.product.sellingPrice || 0) * line.qty, 0);
  return { items, subtotal };
}

function renderCart() {
  const wrap = document.querySelector('#cartItems');
  const sum = document.querySelector('#cartSummary');
  if (!wrap || !sum) return;
  if (!state.cart.length) {
    wrap.innerHTML = '<div class="empty drawer-empty"><h3>Your bag is empty.</h3><p>Explore the Jaripatta colour edit.</p><a class="text-link" href="#/collections/all-shawls" data-route="collection" data-category="All">SHOP SHAWLS →</a></div>';
    sum.innerHTML = '';
    bindDynamic();
    return;
  }
  wrap.innerHTML = state.cart.map(line => {
    const p = productById(line.id);
    if (!p) return '';
    return `<div class="cart-line"><img src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt="${escapeHtml(p.name)}"><div class="cart-copy"><strong>${escapeHtml(p.shortName || p.name)}</strong><span>${escapeHtml(p.colour)} · 100% Woollen</span><div class="qty"><button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${line.qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">+</button></div></div><div class="cart-line-price"><strong>${money(p.sellingPrice * line.qty)}</strong><button class="remove-line" data-remove="${p.id}">Remove</button></div></div>`;
  }).join('');
  const { subtotal } = cartTotals();
  const mrpTotal = state.cart.reduce((v,line) => v + Number(productById(line.id)?.mrp || productById(line.id)?.sellingPrice || 0) * line.qty, 0);
  const saving = Math.max(0, mrpTotal - subtotal);
  sum.innerHTML = `<div class="summary-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div>${saving ? `<div class="summary-saving"><span>Preview savings</span><strong>${money(saving)}</strong></div>` : ''}<p class="drawer-note">ShopDeck price snapshot. No real orders are placed here. Final shipping and offers are excluded.</p><button class="btn wide" id="checkoutBtn">PROCEED TO CHECKOUT</button>`;
  wrap.querySelectorAll('[data-qty]').forEach(btn => btn.addEventListener('click', () => {
    const line = state.cart.find(item => item.id === Number(btn.dataset.qty));
    if (!line) return;
    line.qty += Number(btn.dataset.delta);
    if (line.qty <= 0) state.cart = state.cart.filter(item => item.id !== line.id);
    saveState(); renderCart();
  }));
  wrap.querySelectorAll('[data-remove]').forEach(btn => btn.addEventListener('click', () => {
    state.cart = state.cart.filter(item => item.id !== Number(btn.dataset.remove));
    saveState(); renderCart();
  }));
  document.querySelector('#checkoutBtn')?.addEventListener('click', () => go('checkout'));
  bindImageFallbacks();
}

function checkoutSummaryMarkup(items, subtotal) {
  return `<aside class="checkout-summary-card"><div class="checkout-summary-head"><span>YOUR ORDER</span><strong>${items.reduce((n,line)=>n+line.qty,0)} ITEM${items.reduce((n,line)=>n+line.qty,0) === 1 ? '' : 'S'}</strong></div><div class="checkout-lines">${items.map(line => `<div class="checkout-line"><div class="checkout-thumb"><img src="${optimizedImage(line.product.images[0])}" data-fallback-src="${line.product.images[0]}" alt=""><span>${line.qty}</span></div><div><strong>${escapeHtml(line.product.shortName || line.product.name)}</strong><small>${escapeHtml(line.product.colour)} · 100% Woollen</small></div><b>${money(line.product.sellingPrice * line.qty)}</b></div>`).join('')}</div><div class="checkout-totals"><div><span>Product subtotal</span><strong>${money(subtotal)}</strong></div><div><span>Shipping</span><span>Set at live integration</span></div><div class="preview-total"><span>Preview total</span><strong>${money(subtotal)}</strong></div></div><p class="checkout-policy-note">Prices are a ShopDeck snapshot, not a live quote. This is a demo: no payment or order is sent. Final delivery charges and offers are not included.</p></aside>`;
}

function renderCheckout() {
  setMeta('Checkout', 'Checkout preview for the Doshi Crafts local website build.');
  const { items, subtotal } = cartTotals();
  if (!items.length) {
    app.innerHTML = `<section class="empty full-empty"><div class="eyebrow">YOUR BAG</div><h1>Your bag is empty.</h1><p>Add a shawl before opening checkout.</p><a class="btn" href="#/collections/all-shawls" data-route="collection" data-category="All">SHOP SHAWLS</a></section>${footer()}`;
    return;
  }
  const saved = safeParse(sessionStorage.getItem('dc_v10_checkout_draft'), {});
  app.innerHTML = `<section class="checkout-page"><div class="checkout-top"><a href="#/" data-route="home" class="checkout-logo"><img src="assets/doshi-logo.svg" alt="Doshi Crafts"></a><div class="checkout-progress"><span class="done">BAG</span><i></i><span class="active">DETAILS</span><i></i><span>CONFIRM</span></div><a class="checkout-back" href="#/collections/all-shawls" data-route="collection" data-category="All">CONTINUE SHOPPING</a></div>
  <div class="checkout-layout"><form class="checkout-form" id="checkoutForm"><div class="checkout-intro"><div class="eyebrow">DOSHI CRAFTS CHECKOUT</div><h1>Almost yours.</h1><p>Try the complete checkout with sample details. No real order, payment or message will be sent.</p></div>
    <section class="checkout-card"><div class="checkout-card-title"><span>01</span><div><h2>Contact</h2><p>Sample contact details for this preview only.</p></div></div><div class="form-grid two"><label>Email<input type="email" name="email" autocomplete="email" required value="${escapeHtml(saved.email || '')}" placeholder="you@example.com"></label><label>Phone<input type="tel" name="phone" autocomplete="tel" required minlength="8" maxlength="20" value="${escapeHtml(saved.phone || '')}" placeholder="+91 98765 43210"></label></div></section>
    <section class="checkout-card"><div class="checkout-card-title"><span>02</span><div><h2>Delivery address</h2><p>Use a sample address to test the layout.</p></div></div><div class="form-grid two"><label class="span-2">Full name<input name="name" autocomplete="name" required value="${escapeHtml(saved.name || '')}" placeholder="Full name"></label><label class="span-2">Address<input name="address" autocomplete="street-address" required value="${escapeHtml(saved.address || '')}" placeholder="House / flat / street"></label><label>City<input name="city" autocomplete="address-level2" required value="${escapeHtml(saved.city || '')}" placeholder="City"></label><label>State<input name="state" autocomplete="address-level1" required value="${escapeHtml(saved.state || '')}" placeholder="State"></label><label>PIN code<input name="pincode" inputmode="numeric" autocomplete="postal-code" required pattern="[0-9]{6}" maxlength="6" value="${escapeHtml(saved.pincode || '')}" placeholder="6-digit PIN"></label><label>Landmark <span class="optional">optional</span><input name="landmark" value="${escapeHtml(saved.landmark || '')}" placeholder="Nearby landmark"></label></div></section>
    <section class="checkout-card"><div class="checkout-card-title"><span>03</span><div><h2>Payment</h2><p>Payment gateway is not connected in this local preview.</p></div></div><div class="payment-options"><label class="payment-option active"><input type="radio" name="payment" value="cod" checked><span><strong>Cash on Delivery</strong><small>Demo checkout method for testing the order flow.</small></span><b>COD</b></label><label class="payment-option disabled"><input type="radio" name="payment" value="online" disabled><span><strong>UPI / Card / Net Banking</strong><small>Enable after a live payment gateway is connected.</small></span><b>SOON</b></label></div></section>
    <label class="checkout-consent"><input type="checkbox" required><span>I understand this is a local demo checkout and no real order or payment will be placed.</span></label><button class="btn checkout-submit" type="submit">PLACE DEMO ORDER</button><p id="checkoutError" class="checkout-error" role="alert"></p>
  </form>${checkoutSummaryMarkup(items, subtotal)}</div></section>${footer()}`;
  const form = document.querySelector('#checkoutForm');
  form?.addEventListener('input', () => {
    const data = Object.fromEntries(new FormData(form).entries());
    sessionStorage.setItem('dc_v10_checkout_draft', JSON.stringify(data));
  });
  form?.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const formData = Object.fromEntries(new FormData(form).entries());
    const order = {
      id: `DC-DEMO-${String(Date.now()).slice(-7)}`,
      createdAt: new Date().toISOString(),
      customer: formData,
      items: items.map(line => ({ id: line.product.id, name: line.product.name, colour: line.product.colour, qty: line.qty, price: line.product.sellingPrice })),
      subtotal
    };
    sessionStorage.setItem('dc_v10_last_demo_order', JSON.stringify(order));
    state.cart = [];
    saveState();
    go('confirmation');
  });
  bindImageFallbacks();
}

function renderConfirmation() {
  setMeta('Order Preview', 'Doshi Crafts local checkout confirmation preview.');
  const order = safeParse(sessionStorage.getItem('dc_v10_last_demo_order'), null);
  if (!order) { go('checkout'); return; }
  app.innerHTML = `<section class="confirmation-page"><div class="confirmation-card"><img class="confirmation-seal" src="assets/doshi-seal.svg" alt=""><div class="eyebrow">CHECKOUT FLOW COMPLETE</div><h1>Thank you, ${escapeHtml((order.customer?.name || 'there').split(' ')[0])}.</h1><p class="confirmation-lead">Your local demo order preview has been created successfully.</p><div class="demo-alert"><strong>No real order was placed.</strong><span>No payment was taken and nothing was sent to a live store.</span></div><div class="confirmation-meta"><div><span>DEMO ORDER</span><strong>${escapeHtml(order.id)}</strong></div><div><span>PREVIEW TOTAL</span><strong>${money(order.subtotal)}</strong></div><div><span>PAYMENT</span><strong>Cash on Delivery · Demo</strong></div></div><div class="confirmation-actions"><a class="btn" href="#/collections/all-shawls" data-route="collection" data-category="All">CONTINUE SHOPPING</a><a class="btn outline" href="#/" data-route="home">BACK HOME</a></div></div></section>${footer()}`;
}

function initProductGallery(p) {
  let active = 0;
  const main = document.querySelector('#productMainImage');
  const thumbs = [...document.querySelectorAll('[data-thumb-index]')];
  const counter = document.querySelector('#productImageCounter');
  const setActive = index => {
    active = (index + p.images.length) % p.images.length;
    main.src = p.images[active];
    main.alt = `${p.name} image ${active + 1}`;
    main.dataset.lightboxMain = String(active);
    counter.textContent = `${active + 1} / ${p.images.length}`;
    thumbs.forEach((thumb, i) => thumb.classList.toggle('active', i === active));
    thumbs[active]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  };
  thumbs.forEach(thumb => thumb.addEventListener('click', () => setActive(Number(thumb.dataset.thumbIndex))));
  document.querySelector('#galleryPrev')?.addEventListener('click', () => setActive(active - 1));
  document.querySelector('#galleryNext')?.addEventListener('click', () => setActive(active + 1));
  main.addEventListener('click', () => openLightbox(p.images, active, p.name, main));
  document.querySelector('#viewFullBtn')?.addEventListener('click', () => openLightbox(p.images, active, p.name, document.querySelector('#viewFullBtn')));
}

const lightboxState = { images: [], index: 0, title: '', scale: 1, panX: 0, panY: 0, returnFocus: null, dragging: false, pointerX: 0, pointerY: 0 };

function openLightbox(images, index = 0, title = 'Product image', returnFocus = null) {
  Object.assign(lightboxState, { images, index, title, scale: 1, panX: 0, panY: 0, returnFocus, dragging: false });
  const lb = document.querySelector('#lightbox');
  lb.classList.add('open');
  lb.setAttribute('aria-hidden', 'false');
  document.body.classList.add('no-scroll');
  renderLightbox();
  document.querySelector('#lightboxClose').focus();
}

function closeLightbox() {
  const lb = document.querySelector('#lightbox');
  if (!lb.classList.contains('open')) return;
  lb.classList.remove('open');
  lb.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('no-scroll');
  const target = lightboxState.returnFocus;
  Object.assign(lightboxState, { scale: 1, panX: 0, panY: 0, dragging: false });
  target?.focus?.();
}

function renderLightbox() {
  const { images, index, title, scale, panX, panY } = lightboxState;
  const img = document.querySelector('#lightboxImage');
  img.src = images[index];
  img.alt = `${title} full screen image ${index + 1}`;
  img.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
  img.style.cursor = scale > 1 ? (lightboxState.dragging ? 'grabbing' : 'grab') : 'zoom-in';
  document.querySelector('#lightboxTitle').textContent = title;
  document.querySelector('#lightboxCounter').textContent = `${index + 1} / ${images.length}`;
  document.querySelector('#lightboxZoomHint').textContent = scale > 1 ? `${scale.toFixed(1)}× · Drag to inspect · double-click to fit` : 'Click or double-tap to zoom';
  document.querySelector('#lightboxThumbs').innerHTML = images.map((src, i) => `<button class="lightbox-thumb ${i === index ? 'active' : ''}" data-lightbox-index="${i}" aria-label="View image ${i + 1}"><img src="${optimizedImage(src)}" data-fallback-src="${src}" alt=""></button>`).join('');
  document.querySelectorAll('[data-lightbox-index]').forEach(btn => btn.addEventListener('click', () => {
    lightboxState.index = Number(btn.dataset.lightboxIndex);
    lightboxState.scale = 1; lightboxState.panX = 0; lightboxState.panY = 0;
    renderLightbox();
  }));
  bindImageFallbacks();
}

function lightboxStep(delta) {
  if (!lightboxState.images.length) return;
  lightboxState.index = (lightboxState.index + delta + lightboxState.images.length) % lightboxState.images.length;
  lightboxState.scale = 1; lightboxState.panX = 0; lightboxState.panY = 0;
  renderLightbox();
}

function toggleZoom(clientX, clientY) {
  if (lightboxState.scale > 1) {
    lightboxState.scale = 1; lightboxState.panX = 0; lightboxState.panY = 0;
  } else {
    lightboxState.scale = 2.25;
    lightboxState.panX = 0; lightboxState.panY = 0;
  }
  renderLightbox();
}

function trapLightboxFocus(event) {
  if (event.key !== 'Tab') return;
  const lb = document.querySelector('#lightbox');
  if (!lb.classList.contains('open')) return;
  const nodes = [...lb.querySelectorAll(focusableSelector)].filter(el => el.offsetParent !== null);
  if (!nodes.length) return;
  const first = nodes[0], last = nodes[nodes.length - 1];
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
}

function setupLightbox() {
  const lb = document.querySelector('#lightbox');
  const stage = document.querySelector('#lightboxStage');
  const img = document.querySelector('#lightboxImage');
  document.querySelector('#lightboxClose').addEventListener('click', closeLightbox);
  document.querySelector('#lightboxPrev').addEventListener('click', () => lightboxStep(-1));
  document.querySelector('#lightboxNext').addEventListener('click', () => lightboxStep(1));
  img.addEventListener('click', e => { if (!lightboxState.dragging) toggleZoom(e.clientX, e.clientY); });
  img.addEventListener('dblclick', e => { e.preventDefault(); toggleZoom(e.clientX, e.clientY); });
  lb.addEventListener('click', e => { if (e.target === lb) closeLightbox(); });
  document.addEventListener('keydown', event => {
    if (lb.classList.contains('open')) {
      if (event.key === 'Escape') closeLightbox();
      else if (event.key === 'ArrowLeft') lightboxStep(-1);
      else if (event.key === 'ArrowRight') lightboxStep(1);
      trapLightboxFocus(event);
      return;
    }
    if (event.key === 'Escape') closeDrawers();
  });

  stage.addEventListener('pointerdown', e => {
    if (lightboxState.scale <= 1) return;
    lightboxState.dragging = true;
    lightboxState.pointerX = e.clientX;
    lightboxState.pointerY = e.clientY;
    stage.setPointerCapture?.(e.pointerId);
    img.style.cursor = 'grabbing';
  });
  stage.addEventListener('pointermove', e => {
    if (!lightboxState.dragging || lightboxState.scale <= 1) return;
    const dx = e.clientX - lightboxState.pointerX;
    const dy = e.clientY - lightboxState.pointerY;
    lightboxState.pointerX = e.clientX; lightboxState.pointerY = e.clientY;
    lightboxState.panX += dx; lightboxState.panY += dy;
    img.style.transform = `translate(${lightboxState.panX}px, ${lightboxState.panY}px) scale(${lightboxState.scale})`;
  });
  const endDrag = () => { lightboxState.dragging = false; img.style.cursor = lightboxState.scale > 1 ? 'grab' : 'zoom-in'; };
  stage.addEventListener('pointerup', endDrag); stage.addEventListener('pointercancel', endDrag);

  let touchStartX = null, touchStartY = null, lastTap = 0, pinchStart = null, pinchScale = 1;
  stage.addEventListener('touchstart', e => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinchStart = Math.hypot(dx, dy); pinchScale = lightboxState.scale;
    } else if (e.touches.length === 1) {
      touchStartX = e.touches[0].clientX; touchStartY = e.touches[0].clientY;
      const now = Date.now();
      if (now - lastTap < 320) { e.preventDefault(); toggleZoom(touchStartX, touchStartY); }
      lastTap = now;
    }
  }, { passive: false });
  stage.addEventListener('touchmove', e => {
    if (e.touches.length === 2 && pinchStart) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const distance = Math.hypot(dx, dy);
      lightboxState.scale = Math.max(1, Math.min(2.5, pinchScale * distance / pinchStart));
      if (lightboxState.scale === 1) { lightboxState.panX = 0; lightboxState.panY = 0; }
      img.style.transform = `translate(${lightboxState.panX}px, ${lightboxState.panY}px) scale(${lightboxState.scale})`;
    }
  }, { passive: false });
  stage.addEventListener('touchend', e => {
    if (pinchStart && e.touches.length < 2) { pinchStart = null; renderLightbox(); return; }
    if (lightboxState.scale > 1 || touchStartX == null) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartX, dy = touch.clientY - touchStartY;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) lightboxStep(dx > 0 ? -1 : 1);
    touchStartX = touchStartY = null;
  }, { passive: true });
}

function bindImageFallbacks() {
  document.querySelectorAll('img[data-fallback-src]').forEach(img => {
    if (img.dataset.fallbackBound) return;
    img.dataset.fallbackBound = '1';
    img.addEventListener('error', () => {
      const fallback = img.dataset.fallbackSrc;
      if (fallback && img.src !== new URL(fallback, location.href).href) img.src = fallback;
    }, { once: true });
  });
}

function bindDynamic() {
  document.querySelectorAll('[data-route]').forEach(el => {
    if (el.dataset.boundRoute) return;
    el.dataset.boundRoute = '1';
    el.addEventListener('click', e => { e.preventDefault(); go(el.dataset.route, el.dataset.category || ''); });
  });
  document.querySelectorAll('[data-product]').forEach(el => {
    if (el.dataset.boundProduct) return;
    el.dataset.boundProduct = '1';
    el.addEventListener('click', e => { e.preventDefault(); go('product', el.dataset.product); });
  });
  document.querySelectorAll('[data-add]').forEach(el => {
    if (el.dataset.boundAdd) return;
    el.dataset.boundAdd = '1';
    el.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      addCart(Number(el.dataset.add));
      if (el.dataset.buy) go('checkout');
    });
  });
  document.querySelectorAll('[data-wish]').forEach(el => {
    if (el.dataset.boundWish) return;
    el.dataset.boundWish = '1';
    el.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); toggleWish(Number(el.dataset.wish)); });
  });
  bindImageFallbacks();
}

function renderSearchResults(query) {
  const out = document.querySelector('#searchResults');
  const q = query.trim().toLowerCase();
  if (!q) {
    out.innerHTML = `<div class="search-start"><p>Search by product name, colour, collection or material.</p><div class="search-popular-title">POPULAR SHADES</div><div class="search-shades">${['Rani Pink','Black','Grey','Royal Blue','Green','Red'].map(c=>`<button data-search-pick="${escapeHtml(c)}"><i style="--shade:${COLOR_HEX[c] || '#999'}"></i>${escapeHtml(c)}</button>`).join('')}</div><a class="text-link search-all" href="#/collections/all-shawls" data-search-all>VIEW ALL SHAWLS →</a></div>`;
    out.querySelectorAll('[data-search-pick]').forEach(btn => btn.addEventListener('click', () => {
      const input = document.querySelector('#searchInput'); input.value = btn.dataset.searchPick; renderSearchResults(input.value); input.focus();
    }));
    out.querySelector('[data-search-all]')?.addEventListener('click', e => { e.preventDefault(); closeDrawers(false); go('collection','All'); });
    return;
  }
  const results = PRODUCTS.filter(p => [p.name, p.shortName, p.category, p.colour, p.material, ...(p.collection || []), ...(p.tags || [])].join(' ').toLowerCase().includes(q));
  if (!results.length) {
    out.innerHTML = `<div class="search-empty"><strong>No shawls found.</strong><span>Try a colour like “Rani Pink”, “Grey” or “Royal Blue”.</span><button class="btn outline" data-reset-search>SHOW ALL SHADES</button></div>`;
    out.querySelector('[data-reset-search]')?.addEventListener('click', () => { const input=document.querySelector('#searchInput'); input.value=''; renderSearchResults(''); input.focus(); });
    return;
  }
  out.innerHTML = `<div class="search-result-count">${results.length} RESULT${results.length === 1 ? '' : 'S'}</div>` + results.map(p => `<a class="search-item" href="${routeFor('product', p.slug)}" data-search-product="${p.slug}"><img src="${optimizedImage(p.images[0])}" data-fallback-src="${p.images[0]}" alt=""><div><strong>${escapeHtml(p.name)}</strong><span>${escapeHtml(p.colour)} · 100% Woollen</span>${priceMarkup(p, true)}</div></a>`).join('');
  out.querySelectorAll('[data-search-product]').forEach(el => el.addEventListener('click', e => { e.preventDefault(); closeDrawers(false); go('product', el.dataset.searchProduct); }));
  bindImageFallbacks();
}

async function boot() {
  try {
    CONFIG = window.DC_CONFIG || {};
    PRODUCTS = window.DC_PRODUCTS || [];
    if ((!PRODUCTS.length || !Object.keys(CONFIG).length) && location.protocol !== 'file:') {
      [CONFIG, PRODUCTS] = await Promise.all([
        fetch('data/config.json', { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error('config.json failed'); return r.json(); }),
        fetch('data/products.json', { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error('products.json failed'); return r.json(); })
      ]);
    }
    if (!PRODUCTS.length) throw new Error('Product data is unavailable');
  } catch (error) {
    console.error(error);
    app.innerHTML = '<section class="empty full-empty"><h1>Website data could not load.</h1><p>Please keep the complete website folder together and reopen index.html.</p></section>';
    return;
  }

  safeAnnouncement();
  updateCounts();
  setupLightbox();

  document.querySelector('#menuBtn').addEventListener('click', e => { drawerReturnFocus = e.currentTarget; openDrawer(document.querySelector('#mobileMenu'), document.querySelector('#closeMenu')); });
  document.querySelector('#closeMenu').addEventListener('click', closeDrawers);
  document.querySelector('#cartBtn').addEventListener('click', e => { drawerReturnFocus = e.currentTarget; renderCart(); openDrawer(document.querySelector('#cartDrawer'), document.querySelector('#closeCart')); });
  document.querySelector('#closeCart').addEventListener('click', closeDrawers);
  document.querySelector('#searchBtn').addEventListener('click', e => { drawerReturnFocus = e.currentTarget; openDrawer(document.querySelector('#searchDrawer'), document.querySelector('#searchInput')); });
  document.querySelector('#closeSearch').addEventListener('click', closeDrawers);
  document.querySelector('#wishlistBtn').addEventListener('click', () => go('wishlist'));
  overlay.addEventListener('click', closeDrawers);
  const input = document.querySelector('#searchInput');
  input.addEventListener('input', () => renderSearchResults(input.value));
  input.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawers(); });
  renderSearchResults('');
  document.querySelector('#searchClear').addEventListener('click', () => { input.value = ''; renderSearchResults(''); input.focus(); });

  window.addEventListener('hashchange', renderRoute);

  // Responsive state cleanup: a mobile menu should never remain over the page
  // after rotating/resizing into the desktop layout.
  const desktopQuery = window.matchMedia('(min-width: 951px)');
  const handleDesktopChange = event => {
    const menu = document.querySelector('#mobileMenu');
    if (event.matches && menu?.classList.contains('open')) closeDrawers(false);
  };
  if (desktopQuery.addEventListener) desktopQuery.addEventListener('change', handleDesktopChange);
  else desktopQuery.addListener?.(handleDesktopChange);

  window.addEventListener('orientationchange', () => {
    if (document.querySelector('#lightbox')?.classList.contains('open')) {
      lightboxState.scale = 1;
      lightboxState.panX = 0;
      lightboxState.panY = 0;
      setTimeout(renderLightbox, 80);
    }
  });

  renderRoute();
}

boot();
