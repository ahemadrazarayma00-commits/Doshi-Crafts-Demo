'use strict';
const input = document.querySelector('#filter');
function showCatalogue() {
  const items = window.DC_CATALOGUE.products.filter(p => p.name.toLowerCase().includes(input.value.trim().toLowerCase()));
  const body = document.querySelector('#rows');
  body.replaceChildren();
  for (const p of items) {
    const row = document.createElement('tr');
    for (const text of [p.name, `₹${p.sellingPrice.toLocaleString('en-IN')}`, `₹${p.mrp.toLocaleString('en-IN')}`]) {
      const cell = document.createElement('td'); cell.textContent = text; row.append(cell);
    }
    body.append(row);
  }
  document.querySelector('#count').textContent = `${items.length} listings`;
}
input.addEventListener('input', showCatalogue);
showCatalogue();
